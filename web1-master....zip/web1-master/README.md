# web1

#shtimi i file-t .php, nese do e shkarkoni siguroni te keni bere start Apache ne paketen tuaj, dhe te ruani file-n brenda xampp/htdocs/folder
